require('dotenv').config()

const https = require('https')
const fs = require('fs')
const path = require('path')
const os = require('os')
const app = require('./server')

const PORT = process.env.PORT || 3000

// Dynamically find the machine's local IP address
function getLocalIP() {
  const interfaces = os.networkInterfaces()
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address
      }
    }
  }
  return 'localhost'
}

// Load the self-signed certificate and private key
const sslOptions = {
  key: fs.readFileSync(path.join(__dirname, 'certs', 'key.pem')),
  cert: fs.readFileSync(path.join(__dirname, 'certs', 'cert.pem'))
}

// Create an HTTPS server instead of plain HTTP
const httpsServer = https.createServer(sslOptions, app)

// Start listening on all interfaces
httpsServer.listen(PORT, '0.0.0.0', () => {
  const localIP = getLocalIP()
  console.log(`FitNova API running on https://localhost:${PORT}`)
  console.log(`Network access: https://${localIP}:${PORT}`)
})

// Export the https server so server.js can attach the WebSocket to it
module.exports = httpsServer