const BASE_URL = `https://${window.location.hostname}:3000`
const WS_URL = `wss://${window.location.hostname}:3000`

export { BASE_URL, WS_URL }